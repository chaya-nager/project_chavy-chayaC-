﻿namespace Common
{
    public class Class1
    {

    }
}