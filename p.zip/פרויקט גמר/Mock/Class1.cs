﻿namespace Mock
{
    public class Class1
    {

    }
}